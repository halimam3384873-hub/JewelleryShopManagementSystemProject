﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace JewelleryShopMS
{
    public partial class InventoryForm : Form
    {
        public InventoryForm()
        {
            InitializeComponent();
        }

       
        private void InventoryForm_Load(object sender, EventArgs e)
        {
            LoadStockGrid();
            LoadSoldItemsGrid();
        }
        string connString = @"Data Source=DESKTOP-2OA29KP;Initial Catalog=JewelleryShopDB;User ID=sa;Password=123;TrustServerCertificate=True;";
        private void LoadStockGrid()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // Sirf woh items dikhayein jo stock mein hain
                string query = "SELECT ItemID, ItemName, Category, StockQuantity FROM JewelleryItems";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvStockDetail.DataSource = dt;
            }
        }
        private void LoadSoldItemsGrid()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // Sold items dikhane ke liye SalesDetails aur JewelleryItems ko join karenge
                string query = @"SELECT J.ItemName, SD.Quantity, S.SaleDate 
                         FROM SaleDetails SD 
                         JOIN JewelleryItems J ON SD.ItemID = J.ItemID 
                         JOIN Sales S ON SD.SaleID = S.SaleID";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvSoldItems.DataSource = dt;
            }
        }

        private void btnStock_Click(object sender, EventArgs e)
        {
            // Check karein ke grid se row select hai ya nahi
            if (dgvStockDetail.SelectedRows.Count > 0)
            {
                // Validation: Check karein ke quantity box khali na ho
                if (!int.TryParse(txtQuantity.Text, out int addedQuantity))
                {
                    MessageBox.Show("Baraye meherbani sahi quantity (numbers) likhein!");
                    return;
                }

                try
                {
                    // Grid se zaroori maloomat nikalna (Cells ka naam database columns jaisa rakhein)
                    int itemID = Convert.ToInt32(dgvStockDetail.SelectedRows[0].Cells["ItemID"].Value);
                    int currentStock = Convert.ToInt32(dgvStockDetail.SelectedRows[0].Cells["StockQuantity"].Value);
                    decimal price = Convert.ToDecimal(dgvStockDetail.SelectedRows[0].Cells["UnitPrice"].Value);

                    // Naya Total Stock (Purana + Naya)
                    int totalStock = currentStock + addedQuantity;

                    using (SqlConnection conn = new SqlConnection(connString))
                    {
                        SqlCommand cmd = new SqlCommand("sp_UpdateJewellery", conn);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ItemID", itemID);
                        cmd.Parameters.AddWithValue("@StockQuantity", totalStock);
                        cmd.Parameters.AddWithValue("@UnitPrice", price);

                        conn.Open();
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Stock successfully update ho gaya!");
                        txtQuantity.Clear();
                        LoadStockGrid(); // Grid refresh karein
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Update error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Pehle grid se ek item select karein!");
            }
        }

        private void dgvStockDetail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvStockDetail.Rows[e.RowIndex];
                txtName.Text = row.Cells["ItemName"].Value.ToString();
                txtQuantity.Text = row.Cells["StockQuantity"].Value.ToString();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminDashboard dash = new AdminDashboard();


            dash.Show();


            this.Close();
        }
    }
}
