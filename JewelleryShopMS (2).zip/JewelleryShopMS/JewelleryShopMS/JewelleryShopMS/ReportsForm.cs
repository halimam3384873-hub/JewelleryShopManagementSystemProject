﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JewelleryShopMS
{
    public partial class ReportsForm : Form
    {
        public ReportsForm()
        {
            InitializeComponent();
        }

        private void ReportsForm_Load(object sender, EventArgs e)
        {

        }
        string connString = @"Data Source=DESKTOP-2OA29KP;Initial Catalog=JewelleryShopDB;User ID=sa;Password=123;TrustServerCertificate=True;";
        private void btnSalesReport_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // Sales aur Customers ko join karenge taki customer ka naam nazar aaye
                string query = @"SELECT S.SaleID, C.FullName AS CustomerName, S.SaleDate, S.TotalAmount 
                         FROM Sales S 
                         JOIN Customers C ON S.CustomerID = C.CustomerID";

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvReports.DataSource = dt; // dgvReports aapke Grid ka naam hai
            }
        }

        private void btnStockReport_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT ItemCode, ItemName, Category, StockQuantity, LowStockAlert FROM JewelleryItems";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvReports.DataSource = dt;
            }
        }

        private void btnCustomerHistory_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"SELECT C.FullName, COUNT(S.SaleID) AS TotalOrders, SUM(S.TotalAmount) AS TotalSpent 
                         FROM Customers C 
                         LEFT JOIN Sales S ON C.CustomerID = S.CustomerID 
                         GROUP BY C.FullName";

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvReports.DataSource = dt;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminDashboard dash = new AdminDashboard();


            dash.Show();


            this.Close();
        }
    }
}
