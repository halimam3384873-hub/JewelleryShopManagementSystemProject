﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace JewelleryShopMS
{
    public partial class CustomerForm : Form
    {
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            LoadCustomerData();
        }
        string connString = @"Data Source=DESKTOP-2OA29KP;Initial Catalog=JewelleryShopDB;User ID=sa;Password=123;TrustServerCertificate=True;";
        // Data load karne ka function (Form Load par call karein)
        private void LoadCustomerData()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM Customers";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvCustomers.DataSource = dt; // Apne DataGridView ka naam dgvCustomers rakhein
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO Customers (FullName, Phone, Address) VALUES (@name, @phone, @address)";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@name", txtName.Text);
                cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@address", txtAddress.Text);

                conn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Customer Added Successfully!");

                LoadCustomerData(); // List update karne ke liye
                ClearFields();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dgvCustomers.SelectedRows.Count > 0)
            {
                int customerID = Convert.ToInt32(dgvCustomers.SelectedRows[0].Cells["CustomerID"].Value);

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    string query = "UPDATE Customers SET FullName=@name, Phone=@phone, Address=@address WHERE CustomerID=@id";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@name", txtName.Text);
                    cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
                    cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                    cmd.Parameters.AddWithValue("@id", customerID);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Updated!");
                    LoadCustomerData();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dgvCustomers.SelectedRows.Count > 0)
            {
                int customerID = Convert.ToInt32(dgvCustomers.SelectedRows[0].Cells["CustomerID"].Value);

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    string query = "DELETE FROM Customers WHERE CustomerID=@id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", customerID);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer Deleted!");
                    LoadCustomerData();
                    ClearFields();
                }
            }
        }

        private void dgvCustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvCustomers.Rows[e.RowIndex];
                txtName.Text = row.Cells["FullName"].Value.ToString();
                txtPhone.Text = row.Cells["Phone"].Value.ToString();
                txtAddress.Text = row.Cells["Address"].Value.ToString();
            }
        }
        private void ClearFields()
        {
            // Yeh aapke TextBoxes ke naam hain, unhein khali karne ke liye
            txtName.Clear();
            txtPhone.Clear();
            txtAddress.Clear();

            // Agar koi aur field hai toh usay bhi yahan clear kar dein
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminDashboard dash = new AdminDashboard();


            dash.Show();


            this.Close();
        }
    }
}
