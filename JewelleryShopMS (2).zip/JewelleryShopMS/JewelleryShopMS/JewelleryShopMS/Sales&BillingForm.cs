﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace JewelleryShopMS
{
    public partial class SalesForm : Form
    {
        public SalesForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        decimal finalTotal = 0;
        decimal discountAmount = 0;
        decimal netTotal = 0;
        private void SalesForm_Load(object sender, EventArgs e)
        {
            dgvBill.Columns.Add("ItemID", "ID");
            dgvBill.Columns.Add("ItemName", "Item Name");
            dgvBill.Columns.Add("Qty", "Quantity");
            dgvBill.Columns.Add("Price", "Price");
            dgvBill.Columns.Add("Total", "Sub Total");
            FillCustomerCombo();
            FillItemCombo();
        }
        string connString = @"Data Source=DESKTOP-2OA29KP;Initial Catalog=JewelleryShopDB;User ID=sa;Password=123;TrustServerCertificate=True;";
        private void FillCustomerCombo()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT CustomerID, FullName FROM Customers";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cmbCustomer.DataSource = dt;
                cmbCustomer.DisplayMember = "FullName";
                cmbCustomer.ValueMember = "CustomerID";
            }
        }
        private void FillItemCombo()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT ItemID, ItemName, UnitPrice FROM JewelleryItems";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                cmbItem.DataSource = dt;
                cmbItem.DisplayMember = "ItemName";
                cmbItem.ValueMember = "ItemID";
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int qty;
            decimal price;

            if (int.TryParse(txtQty.Text, out qty) && decimal.TryParse(txtPrice.Text, out price))
            {
                decimal subtotal = qty * price;

                // Row add karna
                dgvBill.Rows.Add(cmbItem.SelectedValue, cmbItem.Text, qty, price, subtotal);

                // Raw Total update karna
                finalTotal += subtotal;

                // --- STEP 2: Discount Logic ko yahin call karein taake screen par update ho ---
                ApplyDiscountLogic();
            }
            else
            {
                MessageBox.Show("Please enter valid Quantity and Price!");
            }
        }

        private void ApplyDiscountLogic()
        {
            decimal discountPercentage = 0;
            netTotal = finalTotal; // Default agar discount na ho
            discountAmount = 0;

            if (finalTotal >= 300000)
            {
                discountPercentage = 30;
            }
            else if (finalTotal >= 200000)
            {
                discountPercentage = 20;
            }
            else if (finalTotal >= 100000)
            {
                discountPercentage = 10;
            }

            if (discountPercentage > 0)
            {
                discountAmount = (finalTotal * discountPercentage) / 100;
                netTotal = finalTotal - discountAmount;
                // Message sirf tab dikhayein jab pehli baar discount limit cross ho (Optional)
            }

            // Screen par updated Discounted total dikhayein
            txtTotal.Text = netTotal.ToString("N2");
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (dgvBill.Rows.Count == 0)
            {
                MessageBox.Show("Pehle cart mein items add karein!");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    foreach (DataGridViewRow row in dgvBill.Rows)
                    {
                        // Khali row se bachne ke liye check
                        if (row.Cells[0].Value == null) continue;

                        string checkStock = "SELECT StockQuantity FROM JewelleryItems WHERE ItemID = @id";
                        SqlCommand cCmd = new SqlCommand(checkStock, conn);

                        // Ab 'row' variable kaam karega kyunke ye loop ke andar hai
                        cCmd.Parameters.AddWithValue("@id", row.Cells[0].Value);

                        int available = Convert.ToInt32(cCmd.ExecuteScalar());

                        if (available < Convert.ToInt32(row.Cells[2].Value))
                        {
                            MessageBox.Show("Stock kam hai for item: " + row.Cells[1].Value);
                            return; // Bill process nahi hoga
                        }
                    }
                    // Step 1: Main Sale record (Sales Table) - Naye Columns ke saath
                    // button2_Click ke andar query update karein
                    string mainSaleQuery = @"INSERT INTO Sales (CustomerID, UserID, SaleDate, FinalTotal, DiscountAmount, NetTotal) 
                       OUTPUT INSERTED.SaleID 
                       VALUES (@custID, @uID, @date, @fTotal, @disc, @nTotal)";

                    SqlCommand mainCmd = new SqlCommand(mainSaleQuery, conn);

                   
                    mainCmd.Parameters.AddWithValue("@custID", cmbCustomer.SelectedValue);
                    mainCmd.Parameters.AddWithValue("@uID", CurrentUser.UserID); // Login se milne wali ID
                    mainCmd.Parameters.AddWithValue("@date", DateTime.Now);
                    mainCmd.Parameters.AddWithValue("@fTotal", finalTotal);      // Original total (Bina discount)
                    mainCmd.Parameters.AddWithValue("@disc", discountAmount);    // Calculate kiya hua discount
                    mainCmd.Parameters.AddWithValue("@nTotal", netTotal);        // Final amount jo customer dega

                    // Iske baad aap ID nikalte hain:
                    int newSaleID = (int)mainCmd.ExecuteScalar();
                    // Step 2: SaleDetails aur Stock Update
                    foreach (DataGridViewRow row in dgvBill.Rows)
                    {
                        if (row.Cells[0].Value != null)
                        {
                            // Detail Insert
                            string detailQuery = @"INSERT INTO SaleDetails (SaleID, ItemID, Quantity, UnitPrice, SubTotal) 
                                             VALUES (@saleID, @itemID, @qty, @price, @subtotal)";
                            SqlCommand detailCmd = new SqlCommand(detailQuery, conn);
                            detailCmd.Parameters.AddWithValue("@saleID", newSaleID);
                            detailCmd.Parameters.AddWithValue("@itemID", row.Cells[0].Value);
                            detailCmd.Parameters.AddWithValue("@qty", row.Cells[2].Value);
                            detailCmd.Parameters.AddWithValue("@price", row.Cells[3].Value);
                            detailCmd.Parameters.AddWithValue("@subtotal", row.Cells[4].Value);
                            detailCmd.ExecuteNonQuery();

                            // Stock Update
                            string updateStock = "UPDATE JewelleryItems SET StockQuantity = StockQuantity - @qty WHERE ItemID = @itemID";
                            SqlCommand stockCmd = new SqlCommand(updateStock, conn);
                            stockCmd.Parameters.AddWithValue("@qty", row.Cells[2].Value);
                            stockCmd.Parameters.AddWithValue("@itemID", row.Cells[0].Value);
                            stockCmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show($"Bill Generated!\nFinal Amount: {netTotal}");

                    // Reset Form
                    dgvBill.Rows.Clear();
                    finalTotal = 0;
                    txtTotal.Text = "0.00";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    
    // ... (LoadStockGrid, LoadItemsForSale waghaira waise hi rahenge)
        
        private void LoadStockGrid()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    string query = "SELECT ItemID, ItemCode, ItemName, Category, StockQuantity, UnitPrice, LowStockAlert FROM JewelleryItems";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvBill.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Data load karne mein masla: " + ex.Message);
            }
        }
        private void cmbItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check karen ke ComboBox khali na ho aur valid ID ho
    if (cmbItem.SelectedValue != null && cmbItem.SelectedIndex != -1)
            {
                // DataRowView error se bachne ke liye safe casting
                if (cmbItem.SelectedValue is DataRowView) return;

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    try
                    {
                        string query = "SELECT UnitPrice FROM JewelleryItems WHERE ItemID = @id";
                        SqlCommand cmd = new SqlCommand(query, conn);

                        // Value ko string mein convert karke parse karna sab se safe hai
                        int selectedID = Convert.ToInt32(cmbItem.SelectedValue);
                        cmd.Parameters.AddWithValue("@id", selectedID);

                        conn.Open();
                        object result = cmd.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            txtPrice.Text = result.ToString();
                        }
                    }
                    catch (Exception ex)
                    {
                        // Error handling taake app crash na ho
                        Console.WriteLine("Price Fetch Error: " + ex.Message);
                    }
                }
            }

        }
        private void LoadItemsForSale()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT ItemID, ItemName FROM JewelleryItems";
                SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                cmbItem.DataSource = dt;
                cmbItem.DisplayMember = "ItemName"; // User ko naam dikhega
                cmbItem.ValueMember = "ItemID";     // Backend mein ID use hogi

                cmbItem.SelectedIndex = -1; // Shuru mein kuch select na ho
            }
        }
        private void CalculateTotalBill()
        {
            decimal price, total;
            int qty;

            if (decimal.TryParse(txtPrice.Text, out price) && int.TryParse(txtQty.Text, out qty))
            {
                total = price * qty;
                txtTotal.Text = total.ToString();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminDashboard dash = new AdminDashboard();

           
            dash.Show();

          
            this.Close();
        }
      
      
    }
            
}
