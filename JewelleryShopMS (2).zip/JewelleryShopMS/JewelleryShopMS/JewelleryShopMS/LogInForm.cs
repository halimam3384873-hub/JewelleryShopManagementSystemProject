﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JewelleryShopMS
{
    public static class CurrentUser
    {
        public static int UserID;
    }
    public partial class LogInForm : Form
    {
        public LogInForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        string connString = @"Data Source=DESKTOP-2OA29KP;Initial Catalog=JewelleryShopDB;User ID=sa;Password=123;TrustServerCertificate=True;";
        private void btnlogin_Click(object sender, EventArgs e)
        {

            using (SqlConnection conn = new SqlConnection(connString))
            {
                // Query mein UserID aur Role dono mangwayein
                string query = "SELECT UserID, Role FROM Users WHERE Username=@user AND PasswordHash=@pass";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@user", txtusername.Text);
                cmd.Parameters.AddWithValue("@pass", txtpassword.Text);

                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    // 1. UserID ko Static variable mein save karein (taake Sales form use kar sake)
                    CurrentUser.UserID = Convert.ToInt32(dt.Rows[0]["UserID"]);

                    // 2. Role nikalein
                    string userRole = dt.Rows[0]["Role"].ToString();

                    MessageBox.Show("Welcome " + txtusername.Text + " (" + userRole + ")");

                    AdminDashboard mainDash = new AdminDashboard();
                    mainDash.UserRole = userRole;
                    mainDash.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password!");
                }
            
        }
            

        }
    }
}
