﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JewelleryShopMS
{
    public partial class AdminDashboard : Form
    {
        public AdminDashboard()
        {
            InitializeComponent();
        }

        private void btnJewellery_Click(object sender, EventArgs e)
        {
            JewelleryForm jewellery = new JewelleryForm(); // Apni jewellery screen ka naam likhein
            jewellery.Show();
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            SalesForm sales = new SalesForm();
            sales.Show();
        
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            CustomerForm customer = new CustomerForm();
            customer.Show();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            InventoryForm inventory = new InventoryForm();
            inventory.Show();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            ReportsForm reports = new ReportsForm();
            reports.Show();
        }
        public string UserRole;
        private void AdminDashboard_Load(object sender, EventArgs e)
        {
            if (UserRole == "Staff")
            {
                btnInventory.Enabled = false; // Inventory button kaam nahi karega
                btnReports.Visible = false;   // Reports button nazar hi nahi aayega

                // Aap text bhi change kar sakti hain
                lblTitle.Text = "Staff Panel - Jewellery Shop";
            }
            else
            {
                lblTitle.Text = "Admin Panel - Jewellery Shop";
            }
        }
    }
}
