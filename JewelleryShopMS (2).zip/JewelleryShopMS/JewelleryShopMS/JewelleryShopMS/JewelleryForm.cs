﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace JewelleryShopMS
{
    public partial class JewelleryForm : Form
    {
        public JewelleryForm()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvJewellery.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dgvJewellery.SelectedRows[0].Cells["ItemID"].Value);
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    string query = "DELETE FROM JewelleryItems WHERE ItemID = @id";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", id);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Deleted!");
                    LoadData();
                }
            }
        }
        string connString = @"Data Source=DESKTOP-2OA29KP;Initial Catalog=JewelleryShopDB;User ID=sa;Password=123;TrustServerCertificate=True;";
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 1. Pehle check karein ke koi box khali to nahi?
            if (string.IsNullOrEmpty(txtItemCode.Text) || string.IsNullOrEmpty(txtWeight.Text) || string.IsNullOrEmpty(txtPrice.Text))
            {
                MessageBox.Show("Baraye meherbani saari maloomat darj karein!");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();

                    // 2. Check karein ke ItemCode pehle se database mein hai ya nahi
                    string checkQuery = "SELECT COUNT(*) FROM JewelleryItems WHERE ItemCode = @code";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                    checkCmd.Parameters.AddWithValue("@code", txtItemCode.Text);

                    int count = (int)checkCmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Yeh Item Code pehle se maujood hai! Naya code istemal karein.");
                        return;
                    }

                    // 3. Agar code naya hai, to Insert karein (Stored Procedure)
                    SqlCommand cmd = new SqlCommand("sp_AddJewelleryItem", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@ItemCode", txtItemCode.Text);
                    cmd.Parameters.AddWithValue("@ItemName", txtName.Text);
                    cmd.Parameters.AddWithValue("@Category", cmbCategory.Text);

                    // TryParse istemal karna zyada behtar hai taake ghalti se text likhne par crash na ho
                    cmd.Parameters.AddWithValue("@WeightInGrams", decimal.Parse(txtWeight.Text));
                    cmd.Parameters.AddWithValue("@UnitPrice", decimal.Parse(txtPrice.Text));
                    cmd.Parameters.AddWithValue("@StockQuantity", int.Parse(txtStock.Text));
                    cmd.Parameters.AddWithValue("@LowStockAlert", 5);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Item Successfully Added!");

                    LoadData(); // Grid refresh karein
                    ClearFields(); // Form saaf karein
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // 1.Check karen ke Grid mein koi row select hai ya nahi
            if (dgvJewellery.CurrentRow == null)
            {
                MessageBox.Show("Pehle list se item select karen!");
                return;
            }

            // 1. Update se pehle Calculation wala function call karen
            // Note: Agar is function mein txtRate ya txtMaking use ho raha hai jo aapke paas nahi hain,
            // to aapko calculate ka logic thora badalna parega.
            try
            {
                CalculatePrice();
            }
            catch
            {
                // Agar CalculatePrice fail ho jaye to koi masla nahi, manually di gayi price use hogi
            }

            using (SqlConnection conn = new SqlConnection(connString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("sp_UpdateJewellery", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    int id = Convert.ToInt32(dgvJewellery.CurrentRow.Cells["ItemID"].Value);

                    // 2. Parameters (Procedure ke mutabiq)
                    cmd.Parameters.AddWithValue("@ItemID", id);
                    cmd.Parameters.AddWithValue("@ItemCode", txtItemCode.Text);
                    cmd.Parameters.AddWithValue("@ItemName", txtName.Text);

                    // Decimal values ko safety ke sath parse karna
                    decimal price, weight;
                    int qty;
                    decimal.TryParse(txtPrice.Text, out price);
                    decimal.TryParse(txtWeight.Text, out weight);
                    int.TryParse(txtStock.Text, out qty);

                    cmd.Parameters.AddWithValue("@UnitPrice", price);
                    cmd.Parameters.AddWithValue("@Weight", weight);
                    cmd.Parameters.AddWithValue("@StockQuantity", qty);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Updated and Calculated Successfully!");
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Database update nahi hua. Row match nahi hui.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Technical Error: " + ex.Message);
                }
            }
        }

        private void CalculatePrice()
        {
            // Agar boxes khali na hon to calculate karein
           // if (double.TryParse(txtWeight.Text, out double weight) &&
           //     double.TryParse(txtRate.Text, out double rate))
            {
               // double totalPrice = weight * rate;
             //   txtPrice.Text = totalPrice.ToString(); // Price box mein total aa jayega
            }
        }

        private void JewelleryForm_Load(object sender, EventArgs e)
        {

            cmbCategory.Items.Add("Ring");
            cmbCategory.Items.Add("Necklace");
            cmbCategory.Items.Add("Bangle");
            cmbCategory.Items.Add("Earrings");

            LoadData();
        }
        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM JewelleryItems";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvJewellery.DataSource = dt; // Aapka DataGridView ka naam dgvJewellery hona chahiye
            }
        }

        private void dgvJewellery_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvJewellery.Rows[e.RowIndex];
                txtItemCode.Text = row.Cells["ItemCode"].Value.ToString();
                txtName.Text = row.Cells["ItemName"].Value.ToString();
                txtPrice.Text = row.Cells["UnitPrice"].Value.ToString();
                txtWeight.Text = row.Cells["WeightInGrams"].Value.ToString();
                cmbCategory.Text = row.Cells["Category"].Value.ToString();
                txtStock.Text = row.Cells["StockQuantity"].Value.ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }
        private void ClearFields()
        {
            txtItemCode.Clear();
            txtName.Clear();
            txtPrice.Clear();
            txtWeight.Clear();
            txtStock.Clear();
            cmbCategory.SelectedIndex = -1;
        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCategory.Text == "Ring")
            {
                txtPrice.Text = "500"; // Constant Price
               // txtWeight.Enabled = false; // Ring ke liye weight ki zaroorat nahi to box band kar dein
                txtWeight.Text = "0";
            }
            else if (cmbCategory.Text == "Necklace")
            {
                txtPrice.Text = "1000";
                //txtWeight.Enabled = false; // Necklace ke liye weight zaroori ho sakta hai
            }
            else if (cmbCategory.Text == "Bangles")
            {
                txtPrice.Text = "1500";
                //txtWeight.Enabled = false; // Necklace ke liye weight zaroori ho sakta hai
            }
            else if (cmbCategory.Text == "Earnings")
            {
                txtPrice.Text = "2000";
               // txtWeight.Enabled = false; // Necklace ke liye weight zaroori ho sakta hai
            }

            CalculateTotal();
        }
        private void CalculateTotal()
        {
            double unitPrice = 0;
            int quantity = 0;

            // Unit Price (Aik cheez ki qeemat)
            double.TryParse(txtPrice.Text, out unitPrice);

            // Stock (Kitni cheezein hain)
            int.TryParse(txtStock.Text, out quantity);

            if (quantity > 1)
            {
                double total = unitPrice * quantity;
                // Aap total ko kisi alag label mein dikha sakti hain ya txtPrice mein hi update kar dein
                txtPrice.Text = total.ToString();
            }
        }

        private void txtStock_TextChanged(object sender, EventArgs e)
        {
            CalculateTotal();
        
    }

        private void dgvJewellery_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvJewellery.Rows[e.RowIndex];

                // In namon ko apne database ke columns se match karen
                txtPrice.Text = row.Cells["UnitPrice"].Value.ToString();
                txtStock.Text = row.Cells["StockQuantity"].Value.ToString();

                // Agar aapke pas ItemCode aur Name ke bhi boxes hain:
                 txtItemCode.Text = row.Cells["ItemCode"].Value.ToString();
                 txtName.Text = row.Cells["ItemName"].Value.ToString();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminDashboard dash = new AdminDashboard();


            dash.Show();


            this.Close();
        }
    }
}
